// File: src/main/java/Main.java
import com.banking.controller.BankController;

public class Main {
    public static void main(String[] args) {
        BankController controller = new BankController();

        // 模拟注册
        controller.handleRegister("alice", "password123");

        // 模拟登录 (注入示例: "admin'; DROP TABLE users; --")
        controller.handleLogin("admin");

        // 模拟交易 (注入示例: "123; rm -rf /")
        controller.handleTransaction("123");
    }
}