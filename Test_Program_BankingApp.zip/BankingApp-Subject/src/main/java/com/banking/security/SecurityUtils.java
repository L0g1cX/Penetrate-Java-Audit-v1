// File: src/main/java/com/banking/security/SecurityUtils.java
package com.banking.security;

public class SecurityUtils {

    /**
     * 模拟一个简单的密码加密/哈希过程。
     */
    public static String hashPassword(String plainPassword) {
        // 故意用一个弱哈希，仅为演示目的
        return plainPassword.toLowerCase();
    }

    /**
     * 模拟一个命令执行清理器（存在缺陷）
     * @param command 用户输入的命令
     * @return 清理后的命令
     */
    public static String sanitizeCommand(String command) {
        // 这个清理器有缺陷，无法防御 ';'
        return command.replace("|", "").trim();
    }
}