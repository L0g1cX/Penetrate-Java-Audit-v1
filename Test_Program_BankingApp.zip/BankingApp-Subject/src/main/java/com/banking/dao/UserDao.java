// File: src/main/java/com/banking/dao/UserDAO.java
package com.banking.dao;

import com.banking.model.User;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UserDAO {

    private Connection getConnection() throws SQLException {
        // 简化连接，实际应用中不应硬编码
        return DriverManager.getConnection("jdbc:h2:mem:testdb", "sa", "");
    }

    /**
     * 根据用户名查找用户
     * 存在 SQL 注入风险，因为参数未使用 PreparedStatement
     * @param username 用户名
     * @return 用户对象
     */
    public User findUserByUsername(String username) {
        String sql = "SELECT * FROM users WHERE username = '" + username + "'";
        System.out.println("Executing SQL: " + sql);
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                return user;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 保存用户
     */
    public boolean saveUser(User user) {
        String sql = "INSERT INTO users (username, password) VALUES ('" +
                     user.getUsername() + "', '" + user.getPassword() + "')";
        System.out.println("Executing SQL: " + sql);
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(sql);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}