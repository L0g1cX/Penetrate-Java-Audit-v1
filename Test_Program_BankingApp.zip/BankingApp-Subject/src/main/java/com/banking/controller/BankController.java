// File: src/main/java/com/banking/controller/BankController.java
package com.banking.controller;

import com.banking.model.User;
import com.banking.service.UserService;
import com.banking.service.TransactionService;

public class BankController {

    private UserService userService = new UserService();
    private TransactionService transactionService = new TransactionService();

    /**
     * 处理用户注册请求
     */
    public void handleRegister(String username, String password) {
        boolean success = userService.registerUser(username, password);
        if (success) {
            System.out.println("Registration successful for: " + username);
        } else {
            System.out.println("Registration failed for: " + username);
        }
    }

    /**
     * 处理用户登录请求
     * 存在 SQL 注入风险，因为 username 参数直接传入
     */
    public User handleLogin(String username) {
        // 直接将用户输入的 username 传递给业务层
        User user = userService.authenticateUser(username);
        if (user != null) {
            System.out.println("Login successful for: " + user.getUsername());
        } else {
            System.out.println("Login failed for: " + username);
        }
        return user;
    }

    /**
     * 处理交易请求
     * 存在命令注入风险，因为 transactionId 参数直接传入
     */
    public void handleTransaction(String transactionId) {
        // 直接将用户输入的 transactionId 传递给业务层
        transactionService.executePostTransactionScript(transactionId);
    }
}