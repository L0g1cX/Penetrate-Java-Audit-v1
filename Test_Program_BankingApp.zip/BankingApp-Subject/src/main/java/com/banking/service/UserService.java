// File: src/main/java/com/banking/service/UserService.java
package com.banking.service;

import com.banking.dao.UserDAO;
import com.banking.model.User;
import com.banking.security.SecurityUtils;

public class UserService {

    private UserDAO userDAO = new UserDAO();

    /**
     * 用户注册
     */
    public boolean registerUser(String username, String password) {
        // 模拟一个简单的检查
        if (username == null || password == null) {
            return false;
        }
        // 使用工具类加密密码
        String hashedPassword = SecurityUtils.hashPassword(password);
        User user = new User(username, hashedPassword);
        return userDAO.saveUser(user);
    }

    /**
     * 用户登录
     * 存在 SQL 注入风险，因为 username 直接传递给 DAO
     */
    public User authenticateUser(String username) {
        // 直接将参数传递给 DAO，未做任何校验或转义
        return userDAO.findUserByUsername(username);
    }
}