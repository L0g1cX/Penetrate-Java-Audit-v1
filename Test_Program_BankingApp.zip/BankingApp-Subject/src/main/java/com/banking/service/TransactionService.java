// File: src/main/java/com/banking/service/TransactionService.java
package com.banking.service;

import com.banking.security.SecurityUtils;
import java.io.IOException;

public class TransactionService {

    /**
     * 模拟一个后台批处理脚本执行功能
     * 存在命令注入风险
     * @param transactionId 交易ID
     */
    public void executePostTransactionScript(String transactionId) {
        // 模拟一个需要执行外部脚本的场景
        String scriptName = "post_process_" + transactionId + ".sh";
        
        // 调用工具类进行清理（但清理不充分）
        String sanitizedScript = SecurityUtils.sanitizeCommand(scriptName);
        
        // 拼接到命令中执行
        String command = "/bin/bash /scripts/" + sanitizedScript;
        
        System.out.println("About to execute: " + command);
        try {
            // 这里是命令注入的危险点
            Runtime.getRuntime().exec(command);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}